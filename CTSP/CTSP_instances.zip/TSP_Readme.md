The file name has a struture
CTSP_"Cities"_C"clusters"_"instance".csv

example:
CTSP_10C2_2.csv

CTSP instance number 2, with 10 cities and 2 clusters

The Struture of the dataFrame is:
Columns named X,Y,Z,W ... (are the cartesian coordinates of each point)
Column cluster (is the cluster number)
Columns named 0,1,2,3,4, ... (are the distance matrix between each row)
